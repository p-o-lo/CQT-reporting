import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm
from matplotlib.ticker import MaxNLocator

QUBIT = 0
with open(f"./swap_q{QUBIT + 1}_coupler.json") as r:
    data = json.load(r)

x = np.array(data["x"])
y = np.array(data["y"])
res = np.array(data["data"]).transpose() * 1e6


levels = MaxNLocator(nbins=100).tick_values(res.min(), res.max())
cmap = plt.get_cmap('inferno')
norm = BoundaryNorm(levels, ncolors=cmap.N, clip=True)
plt.imshow(res, cmap, norm, extent=(x[0], x[-1], y[-1], y[0]),
                aspect="auto", origin="upper", interpolation='none')
cbar = plt.colorbar()
cbar.set_label("Transmission [ADC arb. units]")
plt.axhline(0.12, label="Coupler Sweetspot", color="blue", linestyle='dashed')
plt.ylabel("Coupler Amplitude [arb. units]")
plt.xlabel("SWAP Length [ns]")
#plt.title(f"Q{QUBIT + 1}")
plt.legend()
plt.tight_layout()
plt.savefig(f"./chevron_swap_q{QUBIT + 1}_coupler.png", dpi=300)
plt.show()
